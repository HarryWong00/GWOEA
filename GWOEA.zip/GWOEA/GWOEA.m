classdef GWOEA < ALGORITHM
% <multi> <real/integer> <large/none>
% dalet         --- 0.5    --- rate of optimization in turn. Default = 1         
% groups        --- 7    --- Grouping method, 1 = linear, 2 = ordered, 3 =  random, 4=different. Default = ordered 
% t            --- 1000 --- Number of evaluations for original problem. Default = 1000
% optimiser     --- 5    --- Internal optimisation algorithm. 1 = SMPSO, 2 = MOEAD, 3 = NSGAII, 4 = NSGAIII, 5=CSO, 6==RVEA. Default = SMPSO. Default = CSO.
    methods  
        function main(Algorithm,Problem) 
            %% Set the default parameters
            [dalet, groups, t, optimiser] = Algorithm.ParameterSet(0.5,7,1000,5); 
            GWOEA_WeightIndividual.Current(Problem); 
            PreMeric=0;  
            mutate_tag=0;
            gNum=ceil(Problem.D/100);
            if Problem.D < 500
                gNum=3;            
            end            
            gamma=gNum;
            t1=t;
            %% 
            if optimiser == 2 || optimiser == 4 || optimiser == 6 || optimiser == 5
               [uniW,Problem.N] = UniformPoint(Problem.N,Problem.M);  
            end
            %% Generate random population 
            Population = Problem.Initialization();
            Algorithm.NotTerminated(Population);            
            %% Start the alternating optimisation 
            PrePopulation=Population;            
            Population = GWOEA_EnvironmentalSelection_RVEA(Population,uniW,(Problem.FE/Problem.maxFE)^2); 
        
            while Problem.FE < Problem.maxFE * dalet                           
              if size(Population,2) <= ceil(Problem.N/2)                 
                    Population = GWOEAfillPopulation(Population,Problem,true); 
              end
                if     optimiser == 6
                     Population = GWOEA_optimiseByRVEA(Problem, Population,uniW, t1);
               elseif  optimiser == 5                    
                    Population = GWOEA_optimiseByCSO(Problem, Population, t1,uniW, false);
                elseif optimiser == 4
                    Population = GWOEA_optimiseByNSGAIII(Problem, Population, uniW, t1, false);
               elseif optimiser == 3
                    Population = GWOEA_optimiseByNSGAII(Problem, Population, t1, false);
               elseif optimiser == 2
                    Population = GWOEA_optimiseByMOEAD(Problem, Population, uniW, t1, false);
                else
                    Population = GWOEA_optimiseBySMPSO(Problem, Population, t1, false);
                end
                Algorithm.NotTerminated(Population); 
                Population = GWOEAeliminateDuplicates(Population); 
                if size(Population,2) <= ceil(Problem.N/2)                 
                    Population = GWOEAfillPopulation(Population,Problem,true); 
                end
                [G,P1] = GWOEA_createGroups(Problem,gamma,Population,groups);                      
                P1_N=size(P1,2); 
                %% 权重优化步              
                alph=0.3;
                beta=3.0;
                [N,D]     = size(Population.decs);
                number = 1;
                PopDec= ones(N, D*number);               
                LOW = Problem.lower;
                UPP = Problem.upper;   
                for i =1: N 
                    unique_numbers = randperm(P1_N, 2*number);
                    if number == 1
                        while i==unique_numbers(1) || i==unique_numbers(2)
                            unique_numbers = randperm(P1_N, 2*number);
                        end
                       x1_index = unique_numbers(1);
                       x2_index = unique_numbers(2);
                    elseif number == 2 
                        while i==unique_numbers(1) || i==unique_numbers(2)|| i==unique_numbers(3)|| i==unique_numbers(4)
                            unique_numbers = randperm(P1_N, 2*number);
                        end
                       x1_index = unique_numbers(1);
                       x2_index = unique_numbers(2);
                       x3_index = unique_numbers(3);
                       x4_index = unique_numbers(4);
                    end
                    x_init=Population(i); 

                   for z = 1:number
                       if z == 1
                          ss1=P1(x1_index);
                          ss2=P1(x2_index); 
                          Dec1=zeros(1,D);
                       elseif z == 2
                           ss1=P1(x3_index);
                           ss2=P1(x4_index);
                           Dec2=zeros(1,D);
                       end                                        
                       weight = zeros(3, gamma);                                    

                       for j = 1:gamma
                           weight(1, j) = 0;
                           weight(2, j) = 0;
                           weight(3, j) = 0;                      
                           group_indic=find(G==j);
                           group_length=numel(group_indic);    
                           sum_vals = sum((x_init.dec(group_indic) - LOW(group_indic)) ./ (UPP(group_indic) - LOW(group_indic)));                       
                           weight(1, j) = sum_vals / group_length;
                           weight(2, j) = sum((ss1.dec(group_indic) - LOW(group_indic)) ./ (UPP(group_indic) - LOW(group_indic))) / group_length;
                           weight(3, j) = sum((ss2.dec(group_indic) - LOW(group_indic)) ./ (UPP(group_indic) - LOW(group_indic))) / group_length;
                           F=rand;                     
                           %F = 0.8 + 0.5*randn; 
                           w = weight(1,j) + F *(weight(2,j) - weight(3,j));
                                          
                            if w < alph * weight(1, j)
                               w = alph * weight(1, j);
                            end        
                            if w > beta * weight(1, j)
                                w = beta * weight(1, j);
                            end 

                            val = w * group_length * (x_init.dec(group_indic) - LOW(group_indic)) ./ (UPP(group_indic) - LOW(group_indic)) ./ sum_vals;
                            val = val .* (UPP(group_indic) - LOW(group_indic)) + LOW(group_indic);                         
                            val(val < LOW(group_indic)) = LOW(group_indic(val < LOW(group_indic)));
                            val(val > UPP(group_indic)) = UPP(group_indic(val > UPP(group_indic)));
                            if z == 1
                                Dec1(group_indic)= val;
                            elseif z==2
                                Dec2(group_indic)= val;
                            end
                       end
                       if z == 1
                           PopDec(i,1:D)=Dec1;
                       elseif z == 2 
                           PopDec(i,D+1:end)=Dec2;
                       end
                       
                   end
                end             
                first_half = PopDec(:, 1:D); 
                second_half = PopDec(:, D+1:end);  
                Pop=vertcat(first_half, second_half);

                %使用混合变异，以提高多样性
                child = combined_mutation(Pop, Problem, mutate_tag);    

                offerstring = vertcat(Pop, child);
                offerstring = Problem.Evaluation(offerstring);
                offerstring = GWOEAeliminateDuplicates(offerstring);
                 Population = GWOEA_EnvironmentalSelection_RVEA([Population,offerstring],uniW,(Problem.FE/Problem.maxFE)^2);
                Algorithm.NotTerminated(Population); 
                    Meric=GD(Population,PrePopulation.objs);
                    if Meric <= 0.01 ||  abs(PreMeric-Meric) <= 0.001                     
                           t1=mapRtoFE(Meric); 
                           gamma=ceil(mapRtoG(Meric,Problem.D));  
                           mutate_tag = 1;  
                    else
                           mutate_tag=0;
                           gamma=gNum;
                           t1=t;
                    end
    
                    PrePopulation=Population;
                    PreMeric=Meric;
               
            end
          

            while  Algorithm.NotTerminated(Population)
                t1=2000;
                optimiser = 5;
                Population = GWOEAfillPopulation(Population, Problem,false);
                 if   optimiser == 6
                     Population = GWOEA_optimiseByRVEA(Problem, Population,uniW, t1);
                elseif    optimiser == 5  
                    Population = GWOEA_optimiseByCSO(Problem, Population, t1,uniW,false);
               elseif optimiser == 4
                    Population = GWOEA_optimiseByNSGAIII(Problem, Population, uniW, t1, false);
                elseif optimiser == 3
                    Population = GWOEA_optimiseByNSGAII(Problem, Population, t1, false);
                elseif optimiser == 2
                    Population = GWOEA_optimiseByMOEAD(Problem, Population, uniW, t1, false);
                else
                    Population = GWOEA_optimiseBySMPSO(Problem, Population, t1, false);
                end
            end
                                  
        end 

        

      end
end



function Population = GWOEAeliminateDuplicates(input)
    % Eliminates duplicates in the population
    [~,ia,~] = unique(input.objs,'rows');
    Population = input(ia);
end

function Population = GWOEAfillPopulation(input, Global,tag)
    % Fills the population with mutations in case its smaller than Global.N
    Population = input;
    theCurrentPopulationSize = size(input,2);
    if tag==1
        N=Global.N;
        N=floor(N/2)*1.2;
    else 
        N=Global.N;
    end
    if theCurrentPopulationSize < N 
        amountToFill    = N-theCurrentPopulationSize;
        FrontNo         = NDSort(input.objs,inf);
        CrowdDis        = CrowdingDistance(input.objs,FrontNo);
        MatingPool      = TournamentSelection(2,amountToFill+1,FrontNo,-CrowdDis);
        Offspring       = OperatorGA(Global,input(MatingPool));
        Population      = [Population,Offspring(1:amountToFill)];
    end
end
