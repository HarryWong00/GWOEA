function [outIndexList,better_Cpop] = GWOEA_createGroups(Problem,numberOfGroups,Population,method)
% Creates groups of the varibales. Three diffeent methods can be
% chosen. The first one uses linear groups, the second orders variables
% by absolute values, the third is a random grouping. For more
% information about these mechanisms see publications (1) and (3 ), see below. 
%原始版文件，或者在基础上进行修改
% ----------------------------------------------------------------------- 
    
    switch method
        case 1 %linear grouping
            varsPerGroup = floor(Problem.D/numberOfGroups);
            outIndexList = [];
            for i = 1:numberOfGroups-1
                outIndexList = [outIndexList, ones(1,varsPerGroup).*i];
            end
            outIndexList = [outIndexList, ones(1,Problem.D-size(outIndexList,2)).*numberOfGroups];
        case 2 %orderByValueGrouping
            varsPerGroup = floor(Problem.D/numberOfGroups);
            vars = xPrime.dec;
            [~,I] = sort(vars);
            outIndexList = ones(1,Problem.D);
            for i = 1:numberOfGroups-1
               outIndexList(I(((i-1)*varsPerGroup)+1:i*varsPerGroup)) = i;
            end
            outIndexList(I(((numberOfGroups-1)*varsPerGroup)+1:end)) = numberOfGroups;           
        case 3 %random Grouping
            varsPerGroup = floor(Problem.D/numberOfGroups);
            outIndexList = [];
            for i = 1:numberOfGroups-1
               outIndexList = [outIndexList, ones(1,varsPerGroup).*i];
            end
            outIndexList = [outIndexList, ones(1,Problem.D-size(outIndexList,2)).*numberOfGroups];
            outIndexList = outIndexList(randperm(length(outIndexList)));
        case 4 %up or down groups
            outIndexList = ones(1,Problem.D);
            xPrimeVars = xPrime.decs;
            xPrimeObjs = xPrime.objs;
            for i = 1 : Problem.D
                newSolVars = xPrime.decs;
                newSolVars(i) = xPrimeVars(i)*1.05;
                newSol = Problem.Evaluation(newSolVars);
                newSolObjs = newSol.objs;
                if newSolObjs(1) < xPrimeObjs(1)
                    outIndexList(i) = 2;
                end
            end
            numberOfGroups = 2;
        
           outIndexList=outIndexList+1;
        case 5 % differential grouping for multi‑objective
            index=randi(size(Population,2));
            xPrime=Population(index);
            % 参数设置
            h   = 1e-2;               % 微扰步长0.01
            eps = 1e-5;               % 交互阈值
            x0  = xPrime.dec;         % 参考解
            D   = Problem.D;          % 决策变量维度
            M   = Problem.M;          % 目标个数
            
            % 评估函数句柄，返回 1×M 向量
            evalF = @(x) Problem.Evaluation(x);
            
            % f(x0)
            f0 = xPrime.obj;           % 1×M 向量
            
            % 初始化每个变量自成一组
            groupID = 1:D;
            
            % 双层循环检测耦合
            for i = 1 : D-1
                % f(x0 + h e_i)
                xi = x0; xi(i) = xi(i) + h;
                fi = evalF(xi);       % 1×M
                fi=fi.obj;
                
                for j = i+1 : D
                    % f(x0 + h e_j)
                    xj = x0; xj(j) = xj(j) + h;
                    fj = evalF(xj);   % 1×M
                    fj=fj.obj;
                    
                    % f(x0 + h e_i + h e_j)
                    xij = xi; xij(j) = xij(j) + h;
                    fij = evalF(xij); % 1×M
                    fij=fij.obj;
                    
                    % 向量差分 Δf_{ij}
                    deltaF = fij - fi - fj + f0;  % 1×M
                    
                    % 用无穷范数判断
                    if max(abs(deltaF)) > eps
                        groupID(j) = groupID(i);
                    end
                end
            end
            
            % 转为连续分组编号
            [~, ~, outIndexList] = unique(groupID);
            realGroupNum = max(outIndexList);
        case 6

          X=xPrime.dec;
          Y=xPrime.obj;
          A=zeros(Problem.M,Problem.D);
          for i=1:Problem.M
            model = TreeBagger(50,X,Y(:,i),'Method','R','OOBPredictorImportance','On');
        % 获取特征重要性评分
            A(i,:)=model.OOBPermutedVarDeltaError;
          end     
        
        % 或者选择前N个特征
           number=numberOfGroups;
           group_size = floor(length(Problem.D)/number);%除最后一组后每组大小 
            for g = 1:number - 1
                group{g} = zeros(1,  group_size);
            end
            
            lSize = Problem.D - (number - 1) *  group_size; %最后一组大小
            group{number} = zeros(1, lSize);
        
            dominateMe = zeros(1, Problem.D); %被支配的数量
            iDominate = cell(1,  Problem.D);%支配的数量
            front = cell(1,  Problem.D + 1); %非支配前沿
        
            for i = 1:length(front)
                front{i} = [];
            end
            for d = 1:Problem.D
                iDominate{d} = [];
            end
        
            for p = 1:Problem.D - 1
                for q = p + 1:Problem.D
                    flagDominate = dominanceCompare(A(:, p), A(:, q), Problem.M);
                    if flagDominate == -1
                        iDominate{p} = [iDominate{p}, q];
                        dominateMe(q) = dominateMe(q) + 1;
                    elseif flagDominate == 1
                        iDominate{q} = [iDominate{q}, p];
                        dominateMe(p) = dominateMe(p) + 1;
                    end
                end
            end
            for p = 1:Problem.D
                if dominateMe(p) == 0
                    front{1} = [front{1}, p];
                end
            end
              i = 1;
            while ~isempty(front{i})
                i = i + 1;
                it1 = front{i - 1};
                for idx = 1:length(it1)
                    it2 = iDominate{it1(idx)};
                    for j = 1:length(it2)
                        index = it2(j);
                        dominateMe(index) = dominateMe(index) - 1;
                        if dominateMe(index) == 0
                            front{i} = [front{i}, index];
                        end
                    end
                end
            end
        %基于重要性分组
            tt = cat(2, front{:});%front按行拼接
              % 根据前沿中的索引来生成按决策变量分组的索引
                % 根据前沿索引值排序
            [~, sortedIndices] = sort(tt);
            for i = 1:number
               if i < number
                  group_indices(sortedIndices((i - 1) * group_size + 1 : i * group_size)) = i;
               else
                  group_indices(sortedIndices((i - 1) * group_size + 1 : end)) = i;
               end    
            end
            outIndexList= group_indices;
            numberOfGroups=number;
       
        case 7 %自适应分组
             % Adaptive variable grouping
                Arc=Population;
                outIndexList=[];
                [better_Cpop,bad_Cpop] = GWOEA_DimSelect(Arc,floor(length(Arc)/4));             
                CbetterDec             = better_Cpop.decs; 
                CbadDec                = bad_Cpop.decs;
                mean_betterCDec        = mean(CbetterDec);
                mean_badCDec           = mean(CbadDec);
                difference             = abs(mean_betterCDec - mean_badCDec); 
                [~, diff_idx]          = sort(difference, 'descend'); 
                varsPerGroup           = floor(Problem.D/numberOfGroups);               
                for i = 1:numberOfGroups  
                    if i < numberOfGroups      
                         outIndexList(diff_idx((i - 1) * varsPerGroup + 1 : i * varsPerGroup)) = i;
                    else
                         outIndexList(diff_idx((i - 1) * varsPerGroup + 1 : end)) = i;
                    end      
               end

    end 
   
end

function flag = dominanceCompare(value1, value2, numObj) %非支配比较
    dominate1 = 0;
    dominate2 = 0;
    
    for i = 1:numObj
        fit1 = value1(i);
        fit2 = value2(i);
        if fit1 > fit2
            flag = -1;
        elseif fit1 < fit2
            flag = 1;
        else
            flag = 0;
        end
        
        if flag == -1
            dominate1 = 1;
        end
        
        if flag == 1
            dominate2 = 1;
        end
    end
    
    if dominate1 == dominate2
        flag = 0;
    elseif dominate1 == 1
        flag = -1;
    else
        flag = 1;
    end
end