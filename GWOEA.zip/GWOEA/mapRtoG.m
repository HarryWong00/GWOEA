function Group = mapRtoG(R,N)   
R_min = 0.001;
R_max = 0.01;
% if N < 500
%     gNum=3;
% elseif  N >= 500 && N < 1000               
%      gNum=ceil(N/100);
% elseif N >= 1000 && N < 2000 
%      gNum=ceil(N/100 *0.8);
% elseif N >= 2000 && N < 3000 
%      gNum=ceil(N/100 * 0.7);
% elseif N >= 3000 && N < 5000 
%     gNum=ceil(N/100 * 0.6);
% else 
%     gNum=ceil(N/100 * 0.5);
% end
G_min =ceil(N/100);
G_max =G_min*2;  


if R < R_min
    R=R_min;
end
if R > R_max
    R=R_max;
end
Group=G_max-(R-R_min)*(G_max-G_min)/(R_max-R_min);
end


