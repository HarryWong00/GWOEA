function Population = GWOEA_optimiseByCSO(GlobalDummy, Population, evaluations,V, isDummy)           
        maximum = currentEvaluations(GlobalDummy, isDummy) + evaluations;
       
        while currentEvaluations(GlobalDummy, isDummy) < maximum
            Fitness = calFitness(Population.objs);
            if length(Population) >= 2
                Rank = randperm(length(Population),floor(length(Population)/2)*2);
            else
                Rank = [1,1];
            end
            Loser  = Rank(1:end/2);
            Winner = Rank(end/2+1:end);
            Change = Fitness(Loser) >= Fitness(Winner);
            Temp   = Winner(Change);
            Winner(Change) = Loser(Change);
            Loser(Change)  = Temp;
            Offspring      = GWOEA_CSO_Operator(GlobalDummy,Population(Loser),Population(Winner));
            Population = GWOEA_EnvironmentalSelection_RVEA([Population,Offspring ],V,(GlobalDummy.FE/GlobalDummy.maxFE)^2);        
        end
end

function e = currentEvaluations(GlobalDummy, isDummy)
    if isDummy == true  
        e = GlobalDummy.Global.FE;
    else
        e = GlobalDummy.FE;
    end
end
function Fitness = calFitness(PopObj)
% Calculate the fitness by shift-based density

    N      = size(PopObj,1);
    fmax   = max(PopObj,[],1);
    fmin   = min(PopObj,[],1);
    PopObj = (PopObj-repmat(fmin,N,1))./repmat(fmax-fmin,N,1);
    Dis    = inf(N);
    for i = 1 : N
        SPopObj = max(PopObj,repmat(PopObj(i,:),N,1));
        for j = [1:i-1,i+1:N]
            Dis(i,j) = norm(PopObj(i,:)-SPopObj(j,:));
        end
    end
    Fitness = min(Dis,[],2);
end