function optimized_result = combined_mutation_origialversion(population, Problem, num_iterations)
%混合变异方法:交换变异+多项式变异
    mutation_prob= 0.5 * (1+rand);%保持变异概率保持在0.75左右
    eta=20;
    num_individuals = size(population, 1);
    lower_bound = repmat(Problem.lower, num_individuals, 1);
    upper_bound = repmat(Problem.upper, num_individuals, 1);   

    all_iterations = cell(num_iterations, 1);

    for iteration = 1:num_iterations
        mutated_population = polynomial_mutation(population, mutation_prob, eta, lower_bound, upper_bound);
        mutated_population = min(max(mutated_population, lower_bound), upper_bound); 

        % 交换变异阶段
        swapped_population = swap_mutation( mutated_population, Problem);
        swapped_population = min(max(swapped_population, lower_bound), upper_bound);
        % 保存本次迭代结果
        all_iterations{iteration} = vertcat(mutated_population, swapped_population);
        population=  swapped_population;       
            
    end
     % 将所有迭代的结果合并在一起
    optimized_result = cell2mat(all_iterations);
    
end


function swapped_population = swap_mutation(population, Problem)    
    
    % 找到具有相同上下界的变量
    same_range_groups = find_same_range_groups(Problem.lower, Problem.upper);
    
    for i = 1:length(same_range_groups)
        group = same_range_groups{i};
        
        if length(group) < 10 && length(group) >= 2
            % 少于10个变量，仅在组内交换
            swap_count = ceil(0.1 * length(group));
            for j = 1:swap_count                
                    pos1 = group(randi(length(group)));
                    pos2 = group(randi(length(group)));
                    % 交换位置
                    while pos1 == pos2
                        pos2 = group(randi(length(group)));
                    end

                    temp = population(:, pos1);
                    population(:, pos1) = population(:, pos2);
                    population(:, pos2) = temp;
                
            end
        else
        % 多于10个变量，分为四个组
           % num_subgroups = randi([4, 10]) ;
           num_variables=size(population,2);
           if num_variables <= 500      
                  num_subgroups = randi([4, 8]);
            elseif num_variables >500 && num_variables <=1000     
                  num_subgroups = randi([6, 12]);  
            elseif num_variables >1000 && num_variables <=2000
                  num_subgroups = randi([8,16]); 
            elseif num_variables >2000 && num_variables <=3000
                 num_subgroups = randi([10, 20]); 
             elseif num_variables >3000 && num_variables <=5000
                  num_subgroups = randi([12, 24]);
            end 
            subgroup_size = ceil(length(group) / num_subgroups);
             
            subgroups = cell(1, num_subgroups);
            indices = randperm(length(group));
            for j = 1:num_subgroups
                subgroups{j} = group(indices((j-1)*subgroup_size + 1:min(j*subgroup_size, length(group))));
            end
            
            % 按顺序放回种群数组
            new_positions = group;
            for j = 1:num_subgroups
                group_start = (j-1)*subgroup_size + 1;
                group_end = min(j*subgroup_size, length(group));
                population(:, new_positions(group_start:group_end)) = population(:, subgroups{j});
            end
        end
    end
    swapped_population = population;
end

function same_range_groups = find_same_range_groups(low, high)
    unique_ranges = unique([low', high'], 'rows');
    same_range_groups = cell(1, size(unique_ranges, 1));
    for i = 1:size(unique_ranges, 1)
        range = unique_ranges(i, :);
        same_range_groups{i} = find(all([low' == range(1), high' == range(2)], 2));
    end
end



function mutated_population = polynomial_mutation(population, mutation_prob, eta, lower_bound, upper_bound)
    % 实现多项式变异策略
    [num_individuals, num_variables] = size(population);
    Site = rand(num_individuals, num_variables) < mutation_prob / num_variables;
    mu = rand(num_individuals, num_variables);
    
    temp1 = Site & (mu <= 0.5);
    delta1 = (2 .* mu(temp1) + (1 - 2 .* mu(temp1)) .* ...
              (1 - (population(temp1) - lower_bound(temp1)) ./ ...
              (upper_bound(temp1) - lower_bound(temp1))).^(eta + 1)).^(1 / (eta + 1)) - 1;
    population(temp1) = population(temp1) + delta1 .* (upper_bound(temp1) - lower_bound(temp1));
    
    temp2 = Site & (mu > 0.5);
    delta2 = 1 - (2 * (1 - mu(temp2)) + 2 * (mu(temp2) - 0.5) .* ...
              (1 - (upper_bound(temp2) - population(temp2)) ./ ...
              (upper_bound(temp2) - lower_bound(temp2))).^(eta + 1)).^(1 / (eta + 1));
    population(temp2) = population(temp2) + delta2 .* (upper_bound(temp2) - lower_bound(temp2));
    
    mutated_population = population;
end

