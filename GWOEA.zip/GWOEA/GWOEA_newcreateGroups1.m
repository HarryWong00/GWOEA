function [outIndexList,numberOfGroups] = GWOEA_newcreateGroups1(Problem,xPrime,number)

   D_amount=Problem.D;%决策变量数量    
   X=xPrime.dec; 
    %阈值1
   threshold_1=floor(D_amount / number);
   GN =0;
    % 初始化分组索引
   group_indices = zeros(size(X));

   %1、查找取值相同的变量
   unique_values=unique(X);
   if length(unique_values)==1 && unique_values == 0
%         X=X+1; %接近决策变量全为0的情况
%         unique_values=unique(X);
        for i=1:number
            start_index = (i - 1) * threshold_1 + 1;
            end_index = i * threshold_1;            
            group_indices(start_index:end_index) = i;
        end
   else


       if length(unique_values) < D_amount %包含重复数据的时候，进入代码块
            count_values=histcounts(X,unique_values); %数据出现频次
       
           % 统计count_values出现次数大于1的变量
            valid_indices = find(count_values >= 2); %找到频次大于2的数据索引
            valid_values = unique_values(valid_indices);
            total_count = sum(count_values(valid_indices));%这些数据的总量    
     
           % 组1：取值相同的均匀分组
            if total_count >= threshold_1 %这些需要分组的总量大于阈值1，就分为两个组   
                group_size = floor(total_count / 2); %每个组的大小   
                % 分配到第一个组
                count_group1 = 0;
                GN1=1;
                GN2=2;
                for i = 1:length(valid_values)
                    indices = find(X == valid_values(i));
                    num_indices = length(indices);%找到需要分组的索引数量
                    count_group1 = count_group1 + num_indices; %组1分组的元素
                    if count_group1 <= group_size                     
                        group_indices(indices) = GN1; % 组1的分组索引为1
                        GN=GN1;
                    else                   
                        % 超过第一个组大小，分到第二个组                   
                        group_indices(indices) = GN2; % 组2的分组索引为2
                        GN=GN2;
                    end
                end
             else
                % 小于等于阈值，直接划分到组1  
                GN = GN + 1;
                for i = 1:length(valid_values)            
                    group_indices(X == valid_values(i)) = GN; % 组1的分组索引为1
                end
            end
      end
    
        % 步骤2: 排序后计算相邻元素的差分值（排除已经分组的部分） 目前，不包含重复数据的时候直接根据差分值分为2个组。
      if any(group_indices==0)
            sorted_unprocessed_decision_variables = sort(X(group_indices == 0)); %实际的决策变量 
            gradients = diff(sorted_unprocessed_decision_variables);
            % 阈值2（当前中位数）
            threshold_2 = median(gradients); % 根据实际情况调整阈值2 
            % 步骤3: 计算相邻元素差分值的分组    
            a=GN + 1;
            b=GN + 2;
            for i = 1:length(gradients)
                if gradients(i) < threshold_2
                    true_index1= (X==sorted_unprocessed_decision_variables(i));
                    group_indices(true_index1) = a; %数组中的索引值应该是整数或者逻辑值
                else
                    true_index2=(X== sorted_unprocessed_decision_variables(i));
                    group_indices(true_index2) = b; 
                end
            end
        
        %     % 步骤4: 判断组2、组3数量是否超过阈值3
        %     c=b+1;
        %     if nnz(group_indices == a) > threshold_1 %nnz是一个函数，用于计算矩阵或数组中非零元素的数量。       
        %         group_indices(group_indices == a) = c; 
        %     end
        %     d=c+1;
        %     if nnz(group_indices == b) > threshold_1
        %         group_indices(group_indices == b) = d; 
        %     end
     end
  end
    group_indices((group_indices==0))=1;
    outIndexList=group_indices;
    total_groups = unique(group_indices);
    total_groups=length(total_groups);
    numberOfGroups=total_groups;
    
    
   

end