function OffspringDec = GWOEA_DEOperator(Global,Parent)
% <operator> <real>
% Differental evolution and polynomial mutation
% CR   ---   1 --- Parameter CR in differental evolution
% F    --- 0.5 --- Parameter F in differental evolution
% proM ---   1 --- The expectation of number of bits doing mutation 
% disM ---  20 --- The distribution index of polynomial mutation

% -----------------------------------------------------------------------
%--------------------------------------------------------------------------

   
    [~,F,proM,disM] = deal(1.0,0.5,5,20); %考虑将CR值做出调整
    CR= 0.5 * (1+rand);%保持变异概率保持在0.75左右
  
    ParentDec = Parent;
    [N,D]     = size(ParentDec);    
    nn=floor(N/3); 
    %% Differental evolution 交叉
    Parent1Dec   = ParentDec(1:nn,:);
    Parent2Dec   = ParentDec(nn+1:nn*2,:);
    Parent3Dec   = ParentDec(nn*2+1:nn*3,:);

    Site1 = rand(nn,D) < CR;
    OffspringDec1= Parent1Dec;
    %F1     = repmat(2 * rand(nn,1),1, D);
    OffspringDec1(Site1) = Parent1Dec(Site1) + F .* (Parent2Dec(Site1)-Parent3Dec(Site1));
    Site2 = rand(nn,D) < CR;
    OffspringDec2= Parent2Dec;
    %F2     = repmat(2 * rand(nn,1) , 1, D);
    OffspringDec2(Site2)= Parent2Dec(Site2) + F .*(Parent1Dec(Site2)-Parent3Dec(Site2));
    Site3 = rand(nn,D) < CR;
    OffspringDec3= Parent3Dec;
    %F3     = repmat(2 * rand(nn,1) , 1, D);
    OffspringDec3(Site3) = Parent3Dec(Site3) + F .*(Parent2Dec(Site3)-Parent1Dec(Site3));
    OffspringDec= vertcat(OffspringDec1,OffspringDec2,OffspringDec3);
    

    %% Polynomial mutation
    N=nn*3;
    Lower = repmat(Global.lower,N,1);
    Upper = repmat(Global.upper,N,1);
    Site  = rand(N,D) < proM/D;
    mu    = rand(N,D);
    temp  = Site & mu<=0.5;
    OffspringDec       = min(max(OffspringDec,Lower),Upper);
    OffspringDec(temp) = OffspringDec(temp)+(Upper(temp)-Lower(temp)).*((2.*mu(temp)+(1-2.*mu(temp)).*...
                         (1-(OffspringDec(temp)-Lower(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1))-1);
   
    temp = Site & mu>0.5; 
    OffspringDec(temp) = OffspringDec(temp)+(Upper(temp)-Lower(temp)).*(1-(2.*(1-mu(temp))+2.*(mu(temp)-0.5).*...
                         (1-(Upper(temp)-OffspringDec(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1)));
%     if ~all(isreal(OffspringDec))
%        disp('数组中存在复数！');  
%    end
    

end