function FE = mapRtoFE(R)   
% 定义 Sigmoid 函数的参数
sigmoid_shift = 0.1; % 平移参数
sigmoid_scale = -10; % 缩放参数

R_min = 0.001;
R_max = 0.01;

FE_min = 1500;
FE_max = 4000;


if R < R_min
    R=R_min;
end
if R > R_max
    R=R_max;
end
% 使用 Sigmoid 函数调整 FE 值
sigmoid_input = (R - R_min) / (R_max - R_min); % 将 R 映射到 0 到 1 之间
sigmoid_output = 1 ./ (1 + exp(-sigmoid_scale * (sigmoid_input - 0.5 + sigmoid_shift))); % 对 Sigmoid 函数进行平移和缩放
FE = FE_min + (FE_max - FE_min) * sigmoid_output; % 将 Sigmoid 输出映射到 FE 范围内
end
