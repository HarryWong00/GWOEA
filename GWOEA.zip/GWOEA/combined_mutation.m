function optimized_result = combined_mutation(population, Problem, flag)
%混合变异方法:交换变异+多项式变异        
    ParentDec = population;
    OffspringDec=ParentDec;
    [N,~]     = size(ParentDec);
    F=rand;
    eta=20;
    for i=1:N    
        idx = randperm(N, 2);
        while i==idx(1) || i==idx(2)
            idx = randperm(N, 2);
        end
        a = ParentDec(idx(1), :);
        b = ParentDec(idx(2), :);   
       
        OffspringDec(i, :)  = ParentDec(i, :) + F * (a - b);
    end
    Lower = repmat(Problem.lower,N,1);
    Upper = repmat(Problem.upper,N,1);
    OffspringDec = min(max(OffspringDec,Lower),Upper);
    
    if flag == 1

            mutated_population=OffspringDec;           
            swapped_population = swap_mutation(mutated_population, Problem);
            swapped_population = min(max(swapped_population, Lower), Upper);            
            optimized_result = swapped_population;
            %optimized_result = vertcat(mutated_population, swapped_population);  
    else            
                       
           mutated_population = polynomial_mutation( OffspringDec, eta, Lower,Upper);
           mutated_population = min(max(mutated_population, Lower), Upper); 
           optimized_result =mutated_population;  
           %optimized_result = vertcat(OffspringDec,mutated_population);  
                      
    end    
         
end

function swapped_population = swap_mutation(population, Problem)    
    
    same_range_groups = find_same_range_groups(Problem.lower, Problem.upper);
    
    for i = 1:length(same_range_groups)
        group = same_range_groups{i};
        
        if length(group) < 10 && length(group) >= 2
            swap_count = ceil(0.1 * length(group));
            for j = 1:swap_count                
                    pos1 = group(randi(length(group)));
                    pos2 = group(randi(length(group)));                    
                    while pos1 == pos2
                        pos2 = group(randi(length(group)));
                    end
                   temp = population(:, pos1);
                    population(:, pos1) = population(:, pos2);
                    population(:, pos2) = temp;
                
            end
        elseif length(group) > 10
            num_variables = size(population, 2);
            G_min=ceil(num_variables/100);
            G_max=ceil(G_min * 1.5);
            num_subgroups = randi([G_min, G_max]);
            subgroup_size = floor(length(group) / num_subgroups);
            subgroups = cell(1, num_subgroups);

            for j = 1:num_subgroups
                if j <= num_subgroups - 1
                    start_idx = (j-1) * subgroup_size + 1;
                    end_idx = j * subgroup_size;
                    subgroups{j} = group(start_idx:end_idx);
                else
                    start_idx = (j-1) * subgroup_size + 1;
                    end_idx = length(group);
                    subgroups{j} = group(start_idx:end_idx);
                end
            end
          
            num_swaps = floor(num_subgroups * 0.40);
            swap_indices = randperm(num_subgroups-1, num_swaps * 2);
            
            for k = 1:num_swaps
                idx1 = swap_indices(2*k - 1);
                idx2 = swap_indices(2*k);             
                temp = population(:, subgroups{idx1});             
                population(:, subgroups{idx1}) = population(:, subgroups{idx2});
                population(:, subgroups{idx2}) = temp;
            end

            if rand < 0.6
                last_group = subgroups{num_subgroups};
                num_to_swap = ceil(0.40 * length(last_group));
                swap_indices = randperm(length(last_group), num_to_swap);
                
                for ii = 1:2:length(swap_indices)-1 
                    temp = population(:, last_group(swap_indices(ii)));
                    population(:, last_group(swap_indices(ii))) = population(:, last_group(swap_indices(ii+1)));
                    population(:, last_group(swap_indices(ii+1))) = temp;
                end
            end        

        end
    end
    swapped_population = population;
end

function same_range_groups = find_same_range_groups(low, high)
    unique_ranges = unique([low', high'], 'rows');
    same_range_groups = cell(1, size(unique_ranges, 1));
    for i = 1:size(unique_ranges, 1)
        range = unique_ranges(i, :);
        same_range_groups{i} = find(all([low' == range(1), high' == range(2)], 2));
    end
end


function mutated_population = polynomial_mutation(population,eta, lower_bound, upper_bound)
    [num_individuals, num_variables] = size(population);
    Site = rand(num_individuals, num_variables) < 0.01;
    mu = rand(num_individuals, num_variables);
    
    temp1 = Site & (mu <= 0.5);
    delta1 = (2 .* mu(temp1) + (1 - 2 .* mu(temp1)) .* ...
              (1 - (population(temp1) - lower_bound(temp1)) ./ ...
              (upper_bound(temp1) - lower_bound(temp1))).^(eta + 1)).^(1 / (eta + 1)) - 1;
    population(temp1) = population(temp1) + delta1 .* (upper_bound(temp1) - lower_bound(temp1));
    
    temp2 = Site & (mu > 0.5);
    delta2 = 1 - (2 * (1 - mu(temp2)) + 2 * (mu(temp2) - 0.5) .* ...
              (1 - (upper_bound(temp2) - population(temp2)) ./ ...
              (upper_bound(temp2) - lower_bound(temp2))).^(eta + 1)).^(1 / (eta + 1));
    population(temp2) = population(temp2) + delta2 .* (upper_bound(temp2) - lower_bound(temp2));
    
    mutated_population = population;
end

