function [outIndexList,numberOfGroups] = GWOEA_newcreateGroups2(Problem,number) 
  %通过随机初始化产生的解，探究变量对目标值的影响----失败
  D_amount=Problem.D;%决策变量数量
  M_amount=Problem.M;%目标值数量  
  init_var=zeros(1,D_amount);  
  best_var=zeros(M_amount,D_amount);  
  % 对每个变量进行处理
  for i = 1:D_amount       
        points = linspace(Problem.lower(i), Problem.upper(i),100 );             
        random_index = randi(100);
        init_var(i) = points(random_index);%随机初始点
  end
  init_soluation=Problem.Evaluation(init_var);%初始解
  %times=10;
  % 定义结构体
%   myStruct = struct('matrix', []);
%   F_mat = repmat(myStruct, times, 1);
  
  AMF=zeros(M_amount,D_amount);
  vecor1=init_var;
  
      for i=1:D_amount
          vecor=linspace(Problem.lower(i), Problem.upper(i),100 ); 
          for j=1:M_amount             
              newvar=zeros(1,100);
              for k=1:100              
                  vecor1(i)=vecor(k);
                  newsol = Problem.Evaluation( vecor1);
                  newvar(k)=newsol.obj(j);                  
              end
              vecor1=init_var;
              [best_value,index]=min(newvar);
              best_var(j,i)=index;%最好取值集合
              AMF(j,i)=init_soluation.obj(j)-best_value; %最好取值时目标改进值           
          end
      end
   

%   disp(AMF);
    
   group_size = floor(Problem.D/number);%除最后一组后每组大小
   
   Dominate=[];
   F=cell(1,Problem.D);
   A=AMF;
    for d = 1:Problem.D        
        Dominate(d).is=0; %is是决策变量d被支配的 数量
        Dominate(d).de = []; %de是决策变量支配的 集合
    end

    for p = 1:Problem.D - 1
        for q = p + 1:Problem.D
            flagDominate = dominanceCompare(A(:, p), A(:, q));            
            if flagDominate == 1  %支配
                Dominate(p).de = [Dominate(p).de , q];%支配q
                Dominate(q).is = Dominate(q).is + 1; %q被支配加1                          
            elseif flagDominate == -1 %被支配
                Dominate(q).de = [Dominate(q).de , p]; %p反被支配
                Dominate(p).is = Dominate(p).is + 1; %p被支配加1
            end
        end
    end
    for p = 1:Problem.D
        if Dominate(p).is == 0       %找到完全不被支配的变量                      
           F{1}=[F{1} p]; %将变量位置加入到前沿F中
        end
    end
      i = 1;
    while ~isempty(F{i})
        i = i + 1;
        it1 = F{i - 1}; %不被支配的变量
        for idx = 1:length(it1)
            it2 = Dominate(it1(idx)).de; %支配的集合
            for j = 1:length(it2)
                index = it2(j);
                Dominate(index).is = Dominate(index).is - 1;
                if Dominate(index).is == 0
                   F{i} = [F{i},index];
                end
            end
        end
    end
%基于重要性分组
    tt = cat(2, F{:});%front按行拼接
      % 根据前沿中的索引来生成按决策变量分组的索引
        % 根据前沿索引值排序
    [~, sortedIndices] = sort(tt);
    for i = 1:number
       if i < number
          group_indices(sortedIndices((i - 1) * group_size + 1 : i * group_size)) = i;
       else
          group_indices(sortedIndices((i - 1) * group_size + 1 : end)) = i;
       end    
    end
    outIndexList= group_indices;
    numberOfGroups=number;
end


function flag = dominanceCompare(value1, value2) %非支配比较
    
    flag=(all(value1 >= value2) && any(value1 > value2)) || (sum(value1) > sum(value2));

%     dominate1 = 0;
%     dominate2 = 0;
%     equal=0;
%     
%     for i = 1:numObj
%         fit1 = value1(i);
%         fit2 = value2(i);
%         if fit1 > fit2 %更重要
%             flag = -1;
%         elseif fit1 < fit2 %更差
%             flag = 1;
%         else
%             flag = 0; %相同
%         end
%         
%         if flag == -1
%             dominate1 = dominate1 + 1;
%         end
%         
%         if flag == 1
%             dominate2 = dominate2+ 1;
%         end
%         if flag==0
%             equal=equal+1;
%         end
%     end
%         
%     
%     if dominate2== 0 && equal ~= numObj
%         flag = -1;
%     elseif dominate1 == 0 && equal ~= numObj
%         flag = 1;
%     end
end