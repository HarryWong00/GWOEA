function [G,Gnumber] = GWOEA_createGroupsdata(Problem,Population,number)
 %使用随机森林获取重要性信息，进而完成分组，设置为通用分组，不需要重复分组
  X=Population.decs;
  Y=Population.objs;
  A=zeros(Problem.M,Problem.D);
  for i=1:Problem.M
    model = TreeBagger(100,X,Y(:,i),'Method','R','OOBPredictorImportance','On'); 
    A(i,:)=model.OOBPermutedVarDeltaError;
  end
   A=abs(A);   
   group_size = floor(Problem.D/number);%每个分组的大小    
   
   Dominate=[]; 
   F=cell(1,Problem.D);

%    dominateMe =0; %被支配的数量
%    iDominate =[];%支配的变量集合
   
    for d = 1:Problem.D        
        Dominate(d).is=0; %is是决策变量d被支配的 数量
        Dominate(d).de = []; %de是决策变量支配的 集合
    end

    for p = 1:Problem.D - 1
        for q = p + 1:Problem.D
            flagDominate = dominanceCompare(A(:, p), A(:, q));            
            if flagDominate == 1  %支配
                Dominate(p).de = [Dominate(p).de , q];%支配q
                Dominate(q).is = Dominate(q).is + 1; %q被支配加1                          
            elseif flagDominate == -1 %被支配
                Dominate(q).de = [Dominate(q).de , p]; %p反被支配
                Dominate(p).is = Dominate(p).is + 1; %p被支配加1
            end
        end
    end
    for p = 1:Problem.D
        if Dominate(p).is == 0  %找到完全不被支配的变量                      
           F{1}=[F{1} p]; %将变量位置加入到前沿F中
        end
    end
      i = 1;
    while ~isempty(F{i})
        i = i + 1;
        it1 = F{i - 1}; %不被支配的变量
        for idx = 1:length(it1)
            it2 = Dominate(it1(idx)).de; %支配的集合
            for j = 1:length(it2)
                index = it2(j);
                Dominate(index).is = Dominate(index).is - 1;
                if Dominate(index).is == 0
                   F{i} = [F{i},index];
                end
            end
        end
    end
    % 去除为空的元素
    filter_F = F(~cellfun(@isempty, F));
    tt = cat(2, filter_F{:});%front按行拼接
      % 根据前沿中的索引来生成按决策变量分组的索引
        % 根据前沿索引值排序  
    for i = 1:number
       if i < number
          group_indices(tt((i - 1) * group_size + 1 : i * group_size)) = i;
       else
          group_indices(tt((i - 1) * group_size + 1 : end)) = i;
       end    
    end
    G= group_indices;
    Gnumber=number;
end


function flag = dominanceCompare(value1, value2) %非支配比较
    
    flag=(all(value1 >= value2) && any(value1 > value2)) || (sum(value1) > sum(value2));


end