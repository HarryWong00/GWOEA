function [better_Cpop,bad_Cpop] = GWOEA_DimSelect(Population,N)
    PopObj          = Population.objs;
    Convergence = CalFitness(PopObj);
    [~,Cidx]        = sort(Convergence);
    better_Cpop     = Population(Convergence==0);  
    temple          = length(Convergence)-N+1;
    bad_Cpop        = Population(Cidx(temple:end));  
    if size(better_Cpop,2) < (size(Population,2)/2)  %没有找到足够数量的收敛性解：存在支配关系，但不存在不被支配个体
        better_Cpop = Population(Cidx(1:floor(size(Population,2)/2)));
    %增加补订的工作
    elseif  size(better_Cpop,2) > size(Population,2) * 0.8        
           Pop_objs=Fitness2(Population.objs);
           [~, index_objs]=sort(Pop_objs,'descend');
           better_Cpop = Population(index_objs(1:floor(size(Population,2)/2)));
           bad_Cpop = Population(index_objs(floor(temple:end)));
    end     
end

function Fitness = Fitness2(PopObj)
% Calculate the fitness by shift-based density

    N      = size(PopObj,1);
    fmax   = max(PopObj,[],1);
    fmin   = min(PopObj,[],1);
    PopObj = (PopObj-repmat(fmin,N,1))./repmat(fmax-fmin,N,1);
    Dis    = inf(N);
    for i = 1 : N
        SPopObj = max(PopObj,repmat(PopObj(i,:),N,1));
        for j = [1:i-1,i+1:N]
            Dis(i,j) = norm(PopObj(i,:)-SPopObj(j,:));
        end
    end
    Fitness = min(Dis,[],2);
end
