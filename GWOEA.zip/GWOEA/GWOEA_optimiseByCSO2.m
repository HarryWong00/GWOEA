function Population = GWOEA_optimiseByCSO2(GlobalDummy, Population, evaluations,V, isDummy)           
        maximum = currentEvaluations(GlobalDummy, isDummy) + evaluations;
       
        while currentEvaluations(GlobalDummy, isDummy) < maximum
            Fitness = calFitness(Population.objs);
            group_size = 3;
            P_N=size(Population,2);
            P_N=floor(P_N/ group_size)*group_size;
            indices = randperm(P_N); % 随机打乱索引                
       
            groups = reshape(indices, [group_size, ceil(P_N / group_size)]);
            for i = 1:size(groups, 2)
                idx1 = groups(1, i);
                idx2 = groups(2, i);
                idx3 = groups(3, i);
                
                % 获取三个个体的适应度
                fitness_values = [Fitness(idx1), Fitness(idx2), Fitness(idx3)];
                % 按适应度从大到小排序
                [~, sorted_indices] = sort(fitness_values, 'descend');
                
                % 根据排序结果分配 Xw, Xl1, Xl2
                Xw(i) = Population(groups(sorted_indices(1), i)); % 最优
                XL1(i) = Population(groups(sorted_indices(2), i)); % 次优
                XL2(i) = Population(groups(sorted_indices(3), i)); % 最差
            end

              Offspring      =  GWOEA_CSO2_Operator(GlobalDummy,XL1,XL2,Xw,isDummy);
              if isDummy==0
                 Population = EnvironmentalSelection_RVEA([Population,Offspring ],V,(GlobalDummy.FE/GlobalDummy.maxFE)^2); 
              else
                 Population = EnvironmentalSelection_RVEA([Population,Offspring ],V,(GlobalDummy.Global.FE/GlobalDummy.Global.maxFE)^2); 
             end
          
        end
end

function e = currentEvaluations(GlobalDummy, isDummy)
    if isDummy == true  
        e = GlobalDummy.Global.FE;
    else
        e = GlobalDummy.FE;
    end
end
function Fitness = calFitness(PopObj)
% Calculate the fitness by shift-based density

    N      = size(PopObj,1);
    fmax   = max(PopObj,[],1);
    fmin   = min(PopObj,[],1);
    PopObj = (PopObj-repmat(fmin,N,1))./repmat(fmax-fmin,N,1);
    Dis    = inf(N);
    for i = 1 : N
        SPopObj = max(PopObj,repmat(PopObj(i,:),N,1));
        for j = [1:i-1,i+1:N]
            Dis(i,j) = norm(PopObj(i,:)-SPopObj(j,:));
        end
    end
    Fitness = min(Dis,[],2);
end