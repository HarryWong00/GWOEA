function Population =  GWOEA_optimiseByRVEA(Problem, Population, V,  evaluations)
 maximum = currentEvaluations(Problem) + evaluations;
 [alpha,fr] = deal(2,0.1);
  while currentEvaluations(Problem) < maximum
      MatingPool = randi(length(Population),1,Problem.N);
      Offspring  = OperatorGA(Problem,Population(MatingPool));
      Population = EnvironmentalSelection_RVEA([Population,Offspring],V,(Problem.FE/Problem.maxFE)^alpha);
      if ~mod(ceil(Problem.FE/Problem.N),ceil(fr*Problem.maxFE/Problem.N))
         V(1:Problem.N,:) = ReferenceVectorAdaptation(Population.objs,V);
      end

  end

end

function e = currentEvaluations(Problem)    
  
  e = Problem.FE;

end

function V = ReferenceVectorAdaptation(PopObj,V)
    V = V.*repmat(max(PopObj,[],1)-min(PopObj,[],1),size(V,1),1);
end