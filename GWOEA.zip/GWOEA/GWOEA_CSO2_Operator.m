function Offspring = GWOEA_CSO2_Operator(Problem,Xl1,Xl2,Xw,isDummy)
% The competitive swarm optimizer

%------------------------------- Copyright --------------------------------
% Copyright (c) 2023 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    %% Parameter setting
    LoserDec1  = Xl1.decs;
    LoserDec2  = Xl2.decs;
    WinnerDec = Xw.decs;
    [N,D]     = size(LoserDec1);
	LoserVel1  = Xl1.adds(zeros(N,D));
    LoserVel2  = Xl2.adds(zeros(N,D));
    WinnerVel = Xw.adds(zeros(N,D));

    %% Competitive swarm optimizer
    r1     = repmat(rand(N,1),1,D);
    r2     = repmat(rand(N,1),1,D);
    r3     = repmat(rand(N,1),1,D);
    F=0.5;

    OffVel1 = r1.*LoserVel1 + r2.*(WinnerDec-LoserDec1)+ F*r3.*(LoserDec2-LoserDec1);
    OffVel2 = r1.*LoserVel2 + r2.*(WinnerDec-LoserDec2);
   
    OffDec1 = LoserDec1 + OffVel1 + r1.*(OffVel1-LoserVel1);
    OffDec2 = LoserDec2 + OffVel2 + r1.*(OffVel2-LoserVel2);
    
    %% Add the winners
    OffDec = [OffDec1;OffDec2;WinnerDec];
    OffVel = [OffVel1;OffVel2;WinnerVel];
 
    %% Polynomial mutation
    Lower  = repmat(Problem.lower,3*N,1);
    Upper  = repmat(Problem.upper,3*N,1);
    disM   = 20;
    Site   = rand(3*N,D) < 1/D;
    mu     = rand(3*N,D);
    temp   = Site & mu<=0.5;
    OffDec       = max(min(OffDec,Upper),Lower);
    OffDec(temp) = OffDec(temp)+(Upper(temp)-Lower(temp)).*((2.*mu(temp)+(1-2.*mu(temp)).*...
                   (1-(OffDec(temp)-Lower(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1))-1);
    temp  = Site & mu>0.5; 
    OffDec(temp) = OffDec(temp)+(Upper(temp)-Lower(temp)).*(1-(2.*(1-mu(temp))+2.*(mu(temp)-0.5).*...
                   (1-(Upper(temp)-OffDec(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1)));
    if isDummy == true
        NewParticles = [];
        for i = 1:3*N
            NewParticles = [NewParticles, S_WOF_WeightIndividual(OffDec(i,:),Problem,OffVel(i,:))];
        end
    else
        NewParticles = Problem.Evaluation(OffDec,OffVel);
    end
	Offspring = NewParticles;
end